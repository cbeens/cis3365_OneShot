package GUI.controller;


import GUI.Class.ProductList;
import GUI.Class.PreferredSupplier;
import GUI.DBconnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.text.Text;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class InventoryQueryController implements Initializable {


    /*************
     * First section controls the popular product tab
     */

    @FXML
    private  Button btn_submit;

    @FXML
    private Label label;

    @FXML
    private TextField txt_product;

    @FXML
    private TextField txt_productdescription;

    @FXML
    private TextField txt_usecount;

    @FXML
    private TextField txt_lastused;

    @FXML
    private TextField txt_search;


    @FXML
    private TableView<ProductList> tableProduct;

    @FXML
    private TableColumn<?, ?> columnProduct;

    @FXML
    private TableColumn<?, ?> columnProductDescription;

    @FXML
    private TableColumn<?, ?> columnUseCount;

    @FXML
    private TableColumn<?, ?> columnLastUsed;

    @FXML
    private Label error_product;

    @FXML
    private Label error_productdescription;

    @FXML
    private Label error_usecount;

    @FXML
    private Label error_lastused;

    @FXML
    private Button btn_okay;

    @FXML
    private Button btn_clear;

    @FXML
    private Text txt_title;

    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;
    private ObservableList<ProductList> data;

    private String inputDate;



    @Override
    public void initialize(URL url, ResourceBundle rb) {
        con = GUI.DBconnection.dConnection();
        data = FXCollections.observableArrayList();
        data1 = FXCollections.observableArrayList();
        setCellTable(); //popular products
        setCellTable1(); //preferred supplier
        loadDataFromDatabase();
        //loadDataFromDatabase1();

    }


    private void setCellTable() {
        columnProduct.setCellValueFactory(new PropertyValueFactory<>("product"));
        columnProductDescription.setCellValueFactory(new PropertyValueFactory<>("productDescription"));
        columnUseCount.setCellValueFactory(new PropertyValueFactory<>("useCount"));
        columnLastUsed.setCellValueFactory(new PropertyValueFactory<>("lastUsed"));
    }

    @FXML
    private void handleSubmit(ActionEvent event) throws IOException {

        inputDate = txt_lastused.getText();
        loadDataFromDatabase();
        txt_title.setText("Popular Products Since " + inputDate);
    }

    private void loadDataFromDatabase(){
        try {
            pst = con.prepareStatement("SELECT \n" +
                    "Product.Prod_Name AS 'Product',\n" +
                    "Product.Prod_Description AS 'Product Description',\n" +
                    "COUNT(Appt_Svc.Svc_Product) AS 'Use Count',\n" +
                    "FORMAT(MAX(A.Appt_Date), 'MM/dd/yyyy') 'Last Used'\n" +
                    "\n" +
                    "FROM Product\n" +
                    "JOIN Appt_Svc ON Product.Prod_Num = Appt_Svc.Svc_Product\n" +
                    "INNER JOIN Appointment A ON Appt_Svc.Appt_Num = A.Appt_Num\n" +
                    "INNER JOIN Week_Day ON A.Appt_Date = Week_Day.Day_Date\n" +
                    "JOIN Work_Week W ON W.Week_Num = Week_Day.Week_Num\n" +
                    "\n" +
                    "WHERE W.Week_End >= ?" +
                    "\n" +
                    "GROUP By Product.Prod_Name, Product.Prod_Description\n" +
                    "\n" +
                    "ORDER BY 'Use Count' DESC;");
            pst.setString(1,inputDate);
            rs = pst.executeQuery();
            while (rs.next()) {
                data.add(new ProductList(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)));
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        tableProduct.setItems(data);
    }

    @FXML
    private void clearTextField(ActionEvent event){
        txt_lastused.clear();
        data.clear();
    }

    /*********
     * Second section controls Preferred Supplier Tab
     */

    @FXML
    private Button btn_submit1;

    @FXML
    private Label label1;

    @FXML
    private TextField txt_supplier;

    @FXML
    private TextField txt_product1;

    @FXML
    private TextField txt_orders;

    @FXML
    private TextField txt_totalqtyordered;

    @FXML
    private TextField txt_totalspent;

    @FXML
    private TableView<PreferredSupplier> tableSupplier;

    @FXML
    private TableColumn<?, ?> columnSupplier;

    @FXML
    private TableColumn<?, ?> columnProduct1;

    @FXML
    private TableColumn<?, ?> columnOrders;

    @FXML
    private TableColumn<?, ?> columnTotalQTYOrdered;

    @FXML
    private TableColumn<?, ?> columnTotalSpent;

    @FXML
    private Button btn_okay1;

    @FXML
    private Button btn_clear1;

    @FXML
    private Text txt_title1;


    private ObservableList<PreferredSupplier> data1;

    private String inputOrder;

    private void setCellTable1() {
        columnSupplier.setCellValueFactory(new PropertyValueFactory<>("supplier"));
        columnProduct1.setCellValueFactory(new PropertyValueFactory<>("product"));
        columnOrders.setCellValueFactory(new PropertyValueFactory<>("orders"));
        columnTotalQTYOrdered.setCellValueFactory(new PropertyValueFactory<>("totalQTYOrdered"));
        columnTotalSpent.setCellValueFactory(new PropertyValueFactory<>("totalSpent"));
    }

    @FXML
    private void handleSubmit1(ActionEvent event) throws IOException {

        inputOrder = txt_product.getText();
        loadDataFromDatabase1();
        txt_title1.setText("Preferred Supplier for " + inputOrder);

    }

    private void loadDataFromDatabase1() {
        try {
            pst = con.prepareStatement("SELECT \n" +
                    "Supplier.Supplier_Name AS 'Supplier',\n" +
                    "Product.Prod_Name AS 'Product',\n" +
                    "COUNT(Order_.Order_Date) AS 'Orders',\n" +
                    "SUM(Order_Line.Line_Qty) AS 'Total QTY Ordered',\n" +
                    "SUM(Order_Line.Line_Total) AS 'Total Spent'\n" +
                    "\n" +
                    "FROM Supplier\n" +
                    "JOIN Order_ ON Supplier.Supplier_Num = Order_.Supplier_Num\n" +
                    "JOIN Order_Line ON Order_.Order_Num = Order_Line.Order_Num\n" +
                    "JOIN Product ON Order_Line.Prod_Num = Product.Prod_Num\n" +
                    "\n" +
                    "WHERE Product.Prod_Name LIKE CONCAT(?,'%')" +
                    "\n GROUP BY Supplier.Supplier_Name, Product.Prod_Name" +
                    "\n" +
                    "ORDER BY 'Total QTY Ordered' DESC;");
            pst.setString(1,inputOrder);
            rs = pst.executeQuery();
            while (rs.next()) {
                data1.add(new PreferredSupplier(rs.getString(1),rs.getString(2),rs.getString(3),
                        rs.getString(4),rs.getString(5)));
            }
        } catch (SQLException ex){
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE,null,ex);
        }
        tableSupplier.setItems(data1);
    }

    @FXML
    private void clearTextField1(ActionEvent event){
        txt_product.clear();
        data1.clear();

    }


    /**************
     * The following controls menu
     */

    @FXML
    //opens up the Membership Reports Screen
    private void launchMembershipReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/membershipQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
        //switchView("membershipQueries.fxml");
    }

    @FXML
    //opens up the customer Dashboard Screen
    public void launchCustomerReport(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/CustomerReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //opens up the Employee Dashboard Screen
    public void launchEmployeeDashboard(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employeeReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointment Reports dashboard
    private void launchAppointmentReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appointmentQuery.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointments screen
    private void launchAppointments(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Employees screen
    private void launchEmployees(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee1.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory screen
    public void launchInventory(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventory.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Customer screen
    private void launchCustomers(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/customer.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the services screen
    private void launchServices(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/service.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the service reports screen
    private void launchServiceReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/serviceQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }
    @FXML
    private void launchScheduleReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/ScheduleQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

}
