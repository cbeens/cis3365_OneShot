package GUI.controller;

import GUI.Class.customerReport;
import GUI.DBconnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CustomerReportController implements Initializable {
    @FXML
    public TableView<customerReport> Prefertableview;
    @FXML
    public TableView<customerReport> Freqtableview;
    @FXML
    public TableView<customerReport> spendtableview;
    @FXML
    private TableColumn<?,?> col1;
    @FXML
    private TableColumn<?,?> col2;
    @FXML
    private TableColumn<?,?> col3;
    @FXML
    private TableColumn<?,?> col4;
    @FXML
    private TableColumn<?,?> col5;
    @FXML
    private TableColumn<?,?> col6;
    @FXML
    private TableColumn<?,?> col7;
    @FXML
    private TableColumn<?,?> col8;
    @FXML
    private TableColumn<?,?> col9;
    @FXML
    private TableColumn<?,?> col10;
    @FXML
    private TableColumn<?,?> col11;
    @FXML
    private TableColumn<?,?> col12;
    @FXML
    private TableColumn<?,?> col13;
    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs= null;
    private ObservableList<customerReport> data;
    private ObservableList<customerReport> data2;
    private ObservableList<customerReport> data3;

    public void initialize(URL url, ResourceBundle rb) {
        firstfunction();
        con = GUI.DBconnection.dConnection();
        data = FXCollections.observableArrayList();
        data2 = FXCollections.observableArrayList();
        data3 = FXCollections.observableArrayList();
        loadDATA();
        loadDATA2();
        loadDATA3();
    }

    private void firstfunction() {
        col1.setCellValueFactory(new PropertyValueFactory<>("name"));
        col2.setCellValueFactory(new PropertyValueFactory<>("visit"));
        col3.setCellValueFactory(new PropertyValueFactory<>("ser"));
        col4.setCellValueFactory(new PropertyValueFactory<>("location"));
        col5.setCellValueFactory(new PropertyValueFactory<>("name"));
        col6.setCellValueFactory(new PropertyValueFactory<>("visit"));
        col7.setCellValueFactory(new PropertyValueFactory<>("total_service"));
        col8.setCellValueFactory(new PropertyValueFactory<>("location"));
        col9.setCellValueFactory(new PropertyValueFactory<>("date"));
        col10.setCellValueFactory(new PropertyValueFactory<>("name"));
        col11.setCellValueFactory(new PropertyValueFactory<>("visit"));
        col12.setCellValueFactory(new PropertyValueFactory<>("spend"));
        col13.setCellValueFactory(new PropertyValueFactory<>("location"));
    }

    public void loadDATA(){
        try {
            pst = con.prepareStatement("SELECT\n" +
                    "  CONCAT(C.Cust_FirstName, ' ', C.Cust_LastName) AS Customer,\n" +
                    "  COUNT(Appointment.Appt_Num) AS Visits,\n" +
                    "  CONCAT(Employee.Emp_Firstname, ' ', Employee.Emp_Lastname) AS 'Servicer',\n" +
                    "  Location.Loc_Street AS Location\n" +
                    "\n" +
                    "FROM Customer C\n" +
                    "       LEFT JOIN Appointment ON C.Cust_Num = Appointment.Cust_Num\n" +
                    "       LEFT JOIN Employee ON Appointment.Emp_Num = Employee.Emp_Num\n" +
                    "       LEFT JOIN Location ON Appointment.Loc_Num = Location.Loc_Num\n" +
                    "\n" +
                    "GROUP BY C.Cust_FirstName, C.Cust_LastName,\n" +
                    "         Employee.Emp_Firstname, Employee.Emp_Lastname, Location.Loc_Street\n" +
                    "\n" +
                    "HAVING COUNT(Appointment.Appt_Num) > 1\n" +
                    "\n" +
                    "ORDER BY Visits DESC;");
            rs = pst.executeQuery();
            while(rs.next()){
                data.add(new customerReport(rs.getString("Customer"),rs.getString("Visits"),
                        rs.getString("Servicer"),rs.getString("Location")));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        Prefertableview.setItems(data);
        //System.out.println(data);

    }
    public void loadDATA2(){
        try {
            pst = con.prepareStatement("SELECT\n" +
                    "CONCAT(C.Cust_FirstName, ' ', C.Cust_LastName) AS Customer,\n" +
                    "COUNT(DISTINCT A.Appt_Date) AS Visits,\n" +
                    "COUNT(S.Svc_Num) AS 'Total Services',\n" +
                    "L.Loc_Street AS Location,\n" +
                    "FORMAT(DATEADD(dd,-60,GETDATE()),'MM/dd/yyyy') AS Since\n" +
                    "\n" +
                    "\n" +
                    "FROM Customer C\n" +
                    "LEFT JOIN Appointment A ON A.Cust_Num = C.Cust_Num\n" +
                    "LEFT JOIN Appt_Svc S ON A.Appt_Num = S.Appt_Num\n" +
                    "LEFT JOIN Location L ON L.Loc_Num = A.Loc_Num\n" +
                    "\n" +
                    "WHERE A.Appt_Num = S.Appt_Num\n" +
                    "AND A.Appt_Date >= DATEADD(dd,-60,GETDATE())\n" +
                    "\n" +
                    "GROUP BY L.Loc_Street, C.Cust_FirstName, C.Cust_LastName\n" +
                    "\n" +
                    "ORDER BY Visits DESC;\n");
            rs = pst.executeQuery();
            while(rs.next()){
                data2.add(new customerReport(rs.getString("Customer"),rs.getString("Visits"),
                        rs.getString("Total Services"),rs.getString("Location"),rs.getString("Since")));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        Freqtableview.setItems(data2);
        //System.out.println(data2);

    }
    public void loadDATA3(){
        try {
            pst = con.prepareStatement("SELECT\n" +
                    "CONCAT(Customer.Cust_FirstName, ' ', Customer.Cust_LastName) AS Customer, \n" +
                    "COUNT(S.Svc_Num) AS 'Total Services',\n" +
                    "CONCAT('$', Appointment.Appt_Total) as 'Total Spent',\n" +
                    "Location.Loc_Street as Location \n" +
                    "\n" +
                    "From Customer\n" +
                    "LEFT JOIN Appointment ON Customer.Cust_Num = Appointment.Cust_Num\n" +
                    "LEFT JOIN Location ON Appointment.Loc_Num = Location.Loc_Num\n" +
                    "LEFT JOIN Appt_Svc S ON Appointment.Appt_Num = S.Appt_Num\n" +
                    "\n" +
                    "WHERE Appointment.Appt_Total = (SELECT (Max(Appointment.Appt_Total)) FROM Appointment)\n" +
                    "\n" +
                    "GROUP BY Customer.Cust_FirstName, Customer.Cust_LastName, Appointment.Appt_Total, Location.Loc_Street;");
            rs = pst.executeQuery();
            while(rs.next()){
                data3.add(new customerReport(rs.getString("Customer"),rs.getString("Total Services"),
                        rs.getString("Total Spent"), rs.getString("Location")));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        spendtableview.setItems(data3);

    }

    @FXML
    //opens up the Membership Reports Screen
    private void launchMembershipReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/membershipQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
        //switchView("membershipQueries.fxml");
    }

    @FXML
    //opens up the Employee Dashboard Screen
    public void launchEmployeeDashboard(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employeeReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointment Reports dashboard
    private void launchAppointmentReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appointmentQuery.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointments screen
    private void launchAppointments(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Employees screen
    private void launchEmployees(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee1.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory Reports screen
    private void launchInventoryReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventoryQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory screen
    public void launchInventory(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventory.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Customer screen
    private void launchCustomers(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/customer.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the services screen
    private void launchServices(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/service.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the service reports screen
    private void launchServiceReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/serviceQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }
    @FXML
    private void launchScheduleReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/ScheduleQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }


}
