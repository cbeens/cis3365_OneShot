package GUI.controller;

import GUI.Class.customer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class MainController implements Initializable{



    @FXML
    private StackPane mainContainer;
        //tableview elements
        @FXML
        public TableView<customer> tableview;
        @FXML
        private TableColumn<?,?> col1;
        @FXML
        private TableColumn<?,?> col2;
    @FXML
    private TableColumn<?,?> col3;

    @FXML
    private TableColumn<?,?> col5;

       private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs= null;
    private ObservableList<customer> data;

        public void initialize(URL url, ResourceBundle rb) {
            //firstfunction();
            con=GUI.DBconnection.dConnection();
            data = FXCollections.observableArrayList();
            //loadDATA();


        }


    /*******
     * We aren't using these for now...
            */

    /*
    public void firstfunction(){
            //set up tableview
            col1.setCellValueFactory(new PropertyValueFactory<>("firstname"));
            col2.setCellValueFactory(new PropertyValueFactory<>("lastname"));
            col3.setCellValueFactory(new PropertyValueFactory<>("Phone"));
            col5.setCellValueFactory(new PropertyValueFactory<>("email"));

            // updata tableview
            tableview.setEditable(true);
            // select mutiple rows once
            tableview.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        }

        public void changefirstname(TableColumn.CellEditEvent editt) {
            customer selectPatient = tableview.getSelectionModel().getSelectedItem();
            selectPatient.setFirstname(editt.getNewValue().toString());
        }

        public void changelastname(TableColumn.CellEditEvent editt) {
            customer selectPatient = tableview.getSelectionModel().getSelectedItem();
            selectPatient.setLastname(editt.getNewValue().toString());
        }

        public void loadDATA(){

            try {
                pst = con.prepareStatement("SELECT * FROM dbo.Customer");
                rs = pst.executeQuery();
                while(rs.next()){
                    data.add(new customer(rs.getString(3),rs.getString(2),rs.getString(4),rs.getString(5)));

                }

            } catch (SQLException ex) {
                Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
            }
            tableview.setItems(data);


        }


    public void NewButten() {    }

        public void deleteButton() {
            ObservableList<customer> selectRow;
            //select items
            selectRow = tableview.getSelectionModel().getSelectedItems();

            for (customer customer : selectRow) {
                tableview.getItems().remove(customer);
            }
        }

        public void newbutt(ActionEvent event) throws IOException {
            //create new scene

            Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/newclient.fxml"));
            Scene NewPatient = new Scene(NewScene);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            //window.getStylesheets().add(style.css);
            window.setScene(NewPatient);
            window.show();

        }

    public void newbutt2(ActionEvent event) throws IOException {
        //create new scene

        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();

    }






    public void appoinment(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();
    }

    public void appoinment2(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appointmentQuery.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();
    }

    public void client(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/Main.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();
    }

    public void employee(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employeeReport.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();
    }

    public void employee1(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee1.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();
    }

    public void inventory(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventory.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();
    }

    public void inventory1() throws Exception {
        switchView("inventory1.fxml");
    }



    public void other() throws Exception {
        switchView("other.fxml");
    }
    public void service(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/service.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();
    }
    public void service1() throws Exception {
        switchView("/fxml/service1.fxml");
    }

    public void switchView(String fileName) throws Exception {
        mainContainer.getChildren().clear();
        AnchorPane anchorPane = new FXMLLoader(getClass().getResource("/fxml/" + fileName)).load();
        mainContainer.getChildren().add(anchorPane);
    }

    */

    /**********
     * The following code is to switch scenes using main menu
     * @param event
     * @throws Exception
     */

    @FXML
    //opens up the Membership Reports Screen
    private void launchMembershipReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/membershipQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
        //switchView("membershipQueries.fxml");
    }

    @FXML
    //opens up the customer Dashboard Screen
    public void launchCustomerReport(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/CustomerReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //opens up the Employee Dashboard Screen
    public void launchEmployeeDashboard(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employeeReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointment Reports dashboard
    private void launchAppointmentReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appointmentQuery.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointments screen
    private void launchAppointments(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Employees screen
    private void launchEmployees(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee1.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory Reports screen
    private void launchInventoryReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventoryQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory screen
    public void launchInventory(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventory.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Customer screen
    private void launchCustomers(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/customer.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the services screen
    private void launchServices(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/service.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the service reports screen
    private void launchServiceReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/serviceQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }
    @FXML
    private void launchScheduleReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/ScheduleQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }
}





