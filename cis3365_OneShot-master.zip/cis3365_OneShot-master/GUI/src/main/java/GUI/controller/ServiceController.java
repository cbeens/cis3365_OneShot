package GUI.controller;

import GUI.Class.customer;
import GUI.Class.service;
import GUI.DBconnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServiceController implements Initializable {

    private StackPane mainContainer;
    //tableview elements
    @FXML
    public TableView<service> servicetableview;
    @FXML
    private TableColumn<service, String> col1;
    @FXML
    private TableColumn<service, String> col2;
    @FXML
    private TableColumn<service, String> col3;

    @FXML
    private TextField number;
    @FXML
    private TextField name;
    @FXML
    private TextField price;


    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs= null;
    private ObservableList<service> data;

    public void initialize(URL url, ResourceBundle rb) {

        //set up tableview
        col1.setCellValueFactory(new PropertyValueFactory<service, String>("number"));
        col2.setCellValueFactory(new PropertyValueFactory<service, String>("Des"));
        col3.setCellValueFactory(new PropertyValueFactory<service, String>("price"));
        con=GUI.DBconnection.dConnection();
        data = FXCollections.observableArrayList();
        loadData();


        /*
        // updata tableview
        servicetableview.setEditable(true);
        col1.setCellFactory(TextFieldTableCell.forTableColumn());
        col2.setCellFactory(TextFieldTableCell.forTableColumn());
        col3.setCellFactory(TextFieldTableCell.forTableColumn());


        // select mutiple rows once
        servicetableview.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        servicetableview.setItems(originalPatient());
        servicetableview.setItems(originalPatient2());
        servicetableview.setItems(originalPatient3());
        */
    }


    public void loadData(){
        data.clear();
        try {
            pst = con.prepareStatement("SELECT Svc_Num, Svc_Desc, CONCAT('$', Svc_Price) Price FROM Service");
            rs = pst.executeQuery();
            while(rs.next()){
                data.add(new service(rs.getInt(1),rs.getString(2),rs.getString(3)));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        servicetableview.setItems(data);
        System.out.println();

    }

    public void addService() {

        String prodName = name.getText();
        Float prodPrice = Float.parseFloat(price.getText());

        try {
            pst = con.prepareStatement("INSERT INTO " +
                    "Service(Svc_Desc, Svc_Price) Values(?,?);");
            pst.setString(1, prodName);
            pst.setFloat(2,prodPrice);


            int i = pst.executeUpdate();
            if (i == 1) {
                System.out.print("Successful");
                loadData();
            }
        } catch (SQLException e) {
            e.printStackTrace(); }

    }


    public void deleteService() {
        ObservableList<service> selectRow;
        int toDelete = 0;

        //select items
        selectRow = servicetableview.getSelectionModel().getSelectedItems();

        for (service services : selectRow) {
            servicetableview.getItems().remove(services);
            toDelete = services.getNumber();
        }

        try {
            pst = con.prepareStatement("DELETE FROM Service \n" +
                    "WHERE Service.Svc_Num = ?;");
            pst.setInt(1,toDelete);

            int i = pst.executeUpdate();
            if (i == 1) {
                System.out.print("Successful");
                loadData();
            }
        } catch (SQLException e) {
            e.printStackTrace(); }
    }



    /*******
     * Switchviews....
     * @throws Exception
     */
    /*
    public void inventory1() throws Exception {
        switchView("inventory1.fxml");
    }
    public void membership(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/membership.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();
    }
    public void other() throws Exception {
        switchView("other.fxml");
    }
    public void service() throws Exception {
        switchView("service.fxml");
    }

    public void service1() throws Exception {
        switchView("/fxml/service1.fxml");
    }

    private void switchView(String fileName) throws Exception {

        mainContainer.getChildren().clear();
        AnchorPane anchorPane = new FXMLLoader(getClass().getResource("/fxml/" + fileName)).load();
        mainContainer.getChildren().add(anchorPane);
    }
    */

    /**********
     * Menu controls
     */

    @FXML
    //opens up the Membership Reports Screen
    private void launchMembershipReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/membershipQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
        //switchView("membershipQueries.fxml");
    }

    @FXML
    //opens up the Employee Dashboard Screen
    public void launchEmployeeDashboard(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employeeReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointment Reports dashboard
    private void launchAppointmentReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appointmentQuery.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointments screen
    private void launchAppointments(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Employees screen
    private void launchEmployees(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee1.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory Reports screen
    private void launchInventoryReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventoryQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory screen
    private void launchInventory(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventory.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Customer screen
    private void launchCustomers(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/customer.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the service reports screen
    private void launchServiceReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/serviceQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }


}
