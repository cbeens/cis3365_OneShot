package GUI.controller;

import GUI.Class.appoinment;
import GUI.Class.busyweek;
import GUI.Class.guestonday;
import GUI.Class.manyapp;
import GUI.DBconnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class appointmentQueryControllor implements Initializable {
    @FXML
    public TableView<busyweek> BusyWeektableview;
    @FXML
    public TableView<manyapp> manyapptableview;
    @FXML
    public TableView<guestonday> guestdayableview;
    @FXML
    private TableColumn<?,?> col1;
    @FXML
    private TableColumn<?,?> col2;
    @FXML
    private TableColumn<?,?> col3;
    @FXML
    private TableColumn<?,?> col4;
    @FXML
    private TableColumn<?,?> col5;
    @FXML
    private TextField search;
    @FXML
    private TableColumn<?,?> col6;
    @FXML
    private TableColumn<?,?> col7;
    @FXML
    private TableColumn<?,?> col8;

    //popular week tableview
    @FXML
    public TableView<appoinment> popweektableview;
    @FXML
    private TableColumn<?,?> popweekcol1;
    @FXML
    private TableColumn<?,?> popweekcol2;
    @FXML
    private TableColumn<?,?> popweekcol3;
    @FXML
    private TableColumn<?,?> popweekcol4;

    @FXML
    private TextField txt_service;

    @FXML
    private Label recentAppt;

    //visits of week
    @FXML
    public TableView<appoinment> visittableview;
    @FXML
    private TableColumn<?,?> visitcol1;
    @FXML
    private TableColumn<?,?> visitcol2;
    @FXML
    private TableColumn<?,?> visitcol3;



    @FXML
    private DatePicker datePicker;

    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs= null;
    private ObservableList<busyweek> data;
    private ObservableList<manyapp> data2;
    private ObservableList<guestonday> data3;
    private ObservableList<appoinment> popweekdata;
    private ObservableList<appoinment> visitdata;

    public void initialize(URL url, ResourceBundle rb) {
        setTables();
        setpopweek();
        setvisit();
        con=GUI.DBconnection.dConnection();
        data = FXCollections.observableArrayList();
        data2 = FXCollections.observableArrayList();
        data3 = FXCollections.observableArrayList();
        popweekdata = FXCollections.observableArrayList();
        visitdata = FXCollections.observableArrayList();

        loadvisitData();
    }



    public void setTables(){
        //set up tableview
        col1.setCellValueFactory(new PropertyValueFactory<>("week"));
        col2.setCellValueFactory(new PropertyValueFactory<>("bookings"));
        col3.setCellValueFactory(new PropertyValueFactory<>("month"));
        col4.setCellValueFactory(new PropertyValueFactory<>("location"));
        col5.setCellValueFactory(new PropertyValueFactory<>("appCount"));
        col6.setCellValueFactory(new PropertyValueFactory<>("appDay"));
        col7.setCellValueFactory(new PropertyValueFactory<>("Day"));
        col8.setCellValueFactory(new PropertyValueFactory<>("bookings"));



    }

    public void setpopweek(){
        popweekcol1.setCellValueFactory(new PropertyValueFactory<>("name"));
        popweekcol2.setCellValueFactory(new PropertyValueFactory<>("appnumber"));
        popweekcol3.setCellValueFactory(new PropertyValueFactory<>("service"));
        popweekcol4.setCellValueFactory(new PropertyValueFactory<>("Date"));
    }

    public void setvisit(){
        visitcol1.setCellValueFactory(new PropertyValueFactory<>("location"));
        visitcol2.setCellValueFactory(new PropertyValueFactory<>("Date"));
        visitcol3.setCellValueFactory(new PropertyValueFactory<>("service"));
    }

    //this holds input month for tables.
    private Date sqlDate;

    @FXML//this allows the date to be used for the tables
    private void submitDate(ActionEvent event) {

        sqlDate = java.sql.Date.valueOf(datePicker.getValue());
        loadBusyWeek();
        loadLocationAppts();
        loadGuestCount();
    }

    @FXML//this clears the tables
    private void clear(ActionEvent event) {
        data.clear();
        data2.clear();
        data3.clear();
    }

    @FXML
    private void handleSubmit1(ActionEvent event){
       data.clear();
        popweektableview.setItems(popweekdata);
        loadpopweekdata();

    }

    public void loadpopweekdata(){
        data.clear();

        try {
            pst = con.prepareStatement("SELECT TOP 10\n" +
                    "concat(Customer.Cust_FirstName, ' ', Customer.Cust_LastName) AS Customer,\n" +
                    "concat(Employee.Emp_Firstname, ' ', Employee.Emp_Lastname) AS Employee,\n" +
                    "Service.Svc_Desc AS 'Service', \n" +
                    "FORMAT(Appointment.Appt_Date, 'MM/dd/yyyy') AS 'Appointment Date'\n" +
                    "\n" +
                    "FROM Customer\n" +
                    "LEFT JOIN Appointment ON Appointment.Cust_Num = Customer.Cust_Num\n" +
                    "LEFT JOIN Employee ON Employee.Emp_Num = Appointment.Emp_Num\n" +
                    "LEFT JOIN Appt_Svc ON Appointment.Appt_Num = Appt_Svc.Appt_Num\n" +
                    "JOIN Service ON Appt_Svc.Svc_Num = Service.Svc_Num\n" +
                    "\n" +
                    "WHERE Service.Svc_Desc LIKE CONCAT('%', ?, '%') \n" +
                    "\n" +
                    "GROUP BY Appointment.Appt_Date, Customer.Cust_FirstName, Customer.Cust_LastName, \n" +
                    "Employee.Emp_Firstname, Employee.Emp_Lastname, Service.Svc_Desc\n" +
                    "\n" +
                    "ORDER BY Appointment.Appt_Date DESC;");

            pst.setString(1, txt_service.getText());
            rs = pst.executeQuery();

            while(rs.next()){

                popweekdata.add(new appoinment( rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        recentAppt.setText("The Most Recent Appointments for " + txt_service.getText());



    }

    //this loads the busiest week table
    public void loadBusyWeek(){
        try {
            pst = con.prepareStatement("SELECT TOP 1\n" +
                    "FORMAT(Work_Week.Week_End, 'MM/dd/yyyy') AS 'Week Ending',\n" +
                    "COUNT(DISTINCT Appointment.Appt_Num) AS 'Total Bookings'\n" +
                    "\n" +
                    "\n" +
                    "FROM Appointment\n" +
                    "LEFT JOIN Week_Day D ON Appointment.Appt_Date = D.Day_Date\n" +
                    "LEFT JOIN Work_Week ON D.Week_Num = Work_Week.Week_Num\n" +
                    "\n" +
                    "WHERE MONTH(Week_Start) = MONTH(?)" +
                    "AND YEAR(Week_Start) = YEAR(?)" +
                    "\n" +
                    "GROUP BY Work_Week.Week_End\n" +
                    "\n" +
                    "ORDER BY 'Total Bookings' DESC;");
            pst.setDate(1,sqlDate);
            pst.setDate(2,sqlDate);
            rs = pst.executeQuery();
            while(rs.next()){
                data.add(new busyweek(rs.getString(1),""+rs.getString(2)));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        BusyWeektableview.setItems(data);
    }

    //this loads how many appointments at a location
    public void loadLocationAppts(){
        try {
            pst = con.prepareStatement("SELECT \n" +
                    "MONTH(Work_Week.Week_Start) AS 'Month',\n" +
                    "CONCAT(Location.Loc_Street, ', ', Zip.Zip_City) AS 'Location',\n" +
                    "COUNT(Appointment.Appt_Num) AS 'Appointment Count'\n" +
                    "\n" +
                    "\n" +
                    "From Location\n" +
                    "INNER JOIN Appointment ON Location.Loc_Num = Appointment.Loc_Num\n" +
                    "INNER JOIN Week_Day D ON D.Day_Date = Appointment.Appt_Date\n" +
                    "JOIN Work_Week ON Work_Week.Week_Num = D.Week_Num\n" +
                    "JOIN Zip ON Location.Zip_Num = Zip.Zip_Num\n" +
                    "\n" +
                    "WHERE MONTH(Work_Week.Week_End) = MONTH(?)" +
                    "AND YEAR(Work_Week.Week_End) = YEAR(?)" +
                    "\n" +
                    "GROUP BY Location.Loc_Street, Zip.Zip_City, MONTH(Work_Week.Week_Start);");
            pst.setDate(1, sqlDate);
            pst.setDate(2,sqlDate);
            rs = pst.executeQuery();
            while(rs.next()){
                data2.add(new manyapp(rs.getString(1),rs.getString(2),rs.getString(3)));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        manyapptableview.setItems(data2);
    }

    //this loads how many guests at each location
    public void loadGuestCount(){
        data3.clear();

        try {
            pst = con.prepareStatement("SELECT \n" +
                    "FORMAT(Appointment.Appt_Date, 'MM/dd/yyyy') AS 'Appointment Date',\n" +
                    "WorkDay.Day_Name AS Day,\n" +
                    "COUNT(Appointment.Appt_Num) AS 'Total Bookings'\n" +
                    "\n" +
                    " \n" +
                    "FROM Appointment\n" +
                    "JOIN Week_Day ON Appointment.Appt_Date = Week_Day.Day_Date\n" +
                    "JOIN Workday ON Week_Day.Day_Num = Workday.Day_Num\n" +
                    " \n" +
                    "WHERE MONTH(Appointment.Appt_Date) = MONTH(?) \n" +
                    "AND YEAR(Appointment.Appt_Date) = YEAR(?)" +
                    "\n" +
                    "GROUP BY Workday.Day_Name, Appointment.Appt_Date;");
            pst.setDate(1,sqlDate);
            pst.setDate(2,sqlDate);
            rs = pst.executeQuery();
            while(rs.next()){
                data3.add(new guestonday(rs.getString(1),rs.getString(2),rs.getString(3)));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        guestdayableview.setItems(data3);
    }

    private void loadvisitData() {
        try {
            pst = con.prepareStatement("SELECT\n" +
                    "Location.Loc_Street AS 'Location',\n" +
                    "CONCAT(Workday.Day_Name, 's') AS 'Day',\n" +
                    "COUNT(Workday.Day_Name) 'Visits'\n" +
                    "\n" +
                    "FROM Appointment\n" +
                    "INNER JOIN Week_Day ON Week_Day.Day_Date = Appointment.Appt_Date\n" +
                    "INNER JOIN Workday ON Workday.Day_Num = Week_Day.Day_Num\n" +
                    "JOIN Location ON Appointment.Loc_Num = Location.Loc_Num\n" +
                    "\n" +
                    "GROUP BY Location.Loc_Street, Workday.Day_Name\n" +
                    "\n" +
                    "ORDER BY " +
                    "COUNT(Workday.Day_Name) DESC;");

            rs = pst.executeQuery();

            while(rs.next()){

                visitdata.add(new appoinment( rs.getString(1), rs.getString(2), "" + rs.getString(3)));
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        visittableview.setItems(visitdata);
    }




    /****************
     * The following codes will switch screens on menu options
     * @param event
     * @throws Exception
     ***************/

    @FXML
    //opens up the Membership Reports Screen
    private void launchMembershipReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/membershipQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
        //switchView("membershipQueries.fxml");
    }

    @FXML
    //opens up the customer Dashboard Screen
    public void launchCustomerReport(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/CustomerReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //opens up the Employee Dashboard Screen
    public void launchEmployeeDashboard(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employeeReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointments screen
    private void launchAppointments(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Employees screen
    private void launchEmployees(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee1.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory Reports screen
    private void launchInventoryReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventoryQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory screen
    public void launchInventory(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventory.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Customer screen
    private void launchCustomers(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/customer.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the services screen
    private void launchServices(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/service.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the service reports screen
    private void launchServiceReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/serviceQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }
    @FXML
    private void launchScheduleReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/ScheduleQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

}
