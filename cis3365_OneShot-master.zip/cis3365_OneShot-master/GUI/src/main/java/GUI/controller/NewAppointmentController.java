package GUI.controller;

import GUI.Class.*;
import GUI.DBconnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NewAppointmentController implements Initializable {


    @FXML
    private ComboBox<employee> combo_servicer;

    @FXML
    private TextField firstName;

    @FXML
    private TextField lastName;

    @FXML
    private TextField number;

    @FXML
    private CheckBox chk_member;

    @FXML
    private DatePicker datePicker;

    @FXML
    private ComboBox<timeslot> combo_time;

    @FXML
    private ComboBox<location> combo_location;

    @FXML
    private ComboBox<AppoinmentService> combo_service;


    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs= null;
    private Statement stmt = null;

    private ObservableList<location> location;
    private ObservableList<timeslot> timeSlot;
    private ObservableList<employee> employee;
    private ObservableList<AppoinmentService> service;

    private BookAppointment booking = new BookAppointment();


    public void initialize(URL url, ResourceBundle rb) {
        //firstfunction();
        con=GUI.DBconnection.dConnection();
        location = FXCollections.observableArrayList();
        timeSlot = FXCollections.observableArrayList();
        employee = FXCollections.observableArrayList();
        service = FXCollections.observableArrayList();
        fillLocationCombo();
        fillTimeCombo();
        fillEmployeeCombo();
        fillServiceCombo();
    }

    //this is to submit the appointment information
    public void submit(ActionEvent event) throws Exception {

        storeInfo();
        getEmployeeNumber();
        getLocationNumber();
        getServiceNumber();
        getApptTotal();
        getSlotNumber();

        addAppointment();

        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        NewPatient.getStylesheets().add("/css/style.css");
        window.setScene(NewPatient);
        window.show();

    }

    @FXML
    //this will close window and go back to main application
    private void cancel(ActionEvent event) {
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.close();
    }

    //fill the location combobox
    public void fillLocationCombo(){

        try {
            pst = con.prepareStatement("SELECT Loc_Street AS Location" +
                    "\n" +
                    "FROM Location;");
            rs = pst.executeQuery();

            while (rs.next()) {

                location.add(new location(rs.getString("Location")));
            }
            pst.close();
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        combo_location.setItems(location);

    }

    //fill the timeslot combobox
    public void fillTimeCombo(){

        try {
            pst = con.prepareStatement("SELECT CONVERT(VARCHAR, Slot_Start, 100) AS 'Time'\n" +
                    "FROM Time_Slot;");
            rs = pst.executeQuery();

            while (rs.next()) {

                timeSlot.add(new timeslot(rs.getString("Time")));
            }
            pst.close();
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        combo_time.setItems(timeSlot);

    }

    //fill the location combobox
    public void fillEmployeeCombo(){

        try {
            pst = con.prepareStatement("SELECT CONCAT(Emp_Firstname, ' ', Emp_Lastname) Name" +
                    "\nFROM Employee;");
            rs = pst.executeQuery();

            while (rs.next()) {

                employee.add(new employee(rs.getString("Name")));
            }
            pst.close();
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        combo_servicer.setItems(employee);

    }

    //fill the service combobox
    public void fillServiceCombo(){

        try {
            pst = con.prepareStatement("SELECT Svc_Desc FROM Service");
            rs = pst.executeQuery();

            while (rs.next()) {

                service.add(new AppoinmentService(rs.getString(1)));
            }
            pst.close();
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        combo_service.setItems(service);

    }


    //this will store the information in the book appointment object
    private void storeInfo(){
        if(chk_member.isSelected())
            booking.setIsMember(true);

        booking.setCustomerFirst(firstName.getText());
        booking.setCustomerLast(lastName.getText());
        booking.setCustomerNumber(Integer.parseInt(number.getText()));

        booking.setEmployee(combo_servicer.getSelectionModel().getSelectedItem().toString());
        booking.setLocation(combo_location.getSelectionModel().getSelectedItem().toString());
        booking.setService(combo_location.getSelectionModel().getSelectedItem().toString());
        booking.setTimeSlot(combo_time.getSelectionModel().getSelectedItem().toString());
        booking.setDate(java.sql.Date.valueOf(datePicker.getValue()));

    }

    /******
     * These get the foreign key values for storing info in database
     */

    private void getCustomerNumber(){
        try {
            pst = con.prepareStatement("SELECT Cust_Num FROM Customer\n" +
                    "WHERE Cust_FirstName = ? \n" +
                    "AND Cust_LastName = ?;");
            pst.setString(1,booking.getCustomerFirst());
            pst.setString(2,booking.getCustomerLast());
            rs = pst.executeQuery();

            if (rs.next()) {

                booking.setEmployeeNumber(rs.getInt(1));
            }
            pst.close();
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void getEmployeeNumber(){
        try {
            pst = con.prepareStatement("SELECT Emp_Num FROM Employee\n" +
                    "WHERE CONCAT(Emp_Firstname, ' ', Emp_Lastname) = ?;");
            pst.setString(1,booking.getEmployee());
            rs = pst.executeQuery();

            if (rs.next()) {

                booking.setEmployeeNumber(rs.getInt(1));
            }
            pst.close();
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void getLocationNumber(){
        try {
            pst = con.prepareStatement("SELECT Loc_Num FROM Location\n" +
                    "WHERE Loc_Street = ?;");
            pst.setString(1,booking.getLocation());
            rs = pst.executeQuery();

            if (rs.next()) {

                booking.setLocationNumber(rs.getInt(1));
            }
            pst.close();
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void getServiceNumber(){
        try {
            pst = con.prepareStatement("SELECT Svc_Num FROM Service\n" +
                    "WHERE Svc_Desc = ?;");
            pst.setString(1,combo_service.getSelectionModel().getSelectedItem().toString());
            rs = pst.executeQuery();

            if (rs.next()) {

                booking.setServiceNumber(rs.getInt(1));
            }
            pst.close();
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(booking.getServiceNumber());
    }

    private void getApptNumber(){
        try {
            pst = con.prepareStatement("SELECT MAX(Appt_Num) FROM Appointment;");

            rs = pst.executeQuery();

            if (rs.next()) {

                booking.setApptNumber(rs.getInt(1));
            }
            pst.close();
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void getSlotNumber(){
        try {
            pst = con.prepareStatement("SELECT Slot_Num FROM Time_Slot\n" +
                    "WHERE Slot_Start = ?;");
            pst.setString(1,booking.getTimeSlot());
            rs = pst.executeQuery();

            if (rs.next()) {

                booking.setSlotNumber(rs.getInt(1));
            }
            pst.close();
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void getApptTotal(){
        try {
            pst = con.prepareStatement("SELECT Svc_Price FROM Service\n" +
                    "WHERE Svc_Num = ?;");
            pst.setFloat(1,booking.getServiceNumber());
            rs = pst.executeQuery();

            if (rs.next()) {

                booking.setApptTotal(rs.getFloat(1));
            }
            pst.close();
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    //this will create the appointment in sql
    private void addAppointment(){

        if (chk_member.isSelected()){
            addMemberRecord();
        }

        //insert a new appointment
        try {
            pst = con.prepareStatement("INSERT INTO Appointment" +
                    "(Cust_Num, Loc_Num, Emp_Num, Appt_Date, Appt_Total)\n" +
                    "VALUES (?,?,?,?,?);");

            pst.setInt(1,booking.getCustomerNumber());
            pst.setInt(2,booking.getLocationNumber());
            pst.setInt(3,booking.getEmployeeNumber());
            pst.setDate(4,booking.getDate());
            pst.setFloat(5,booking.getApptTotal());

            pst.executeUpdate();

            pst.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }

        getApptNumber();
        int apptNum = booking.getApptNumber();

        //insert a new appointment time
        try {
            pst = con.prepareStatement("INSERT INTO Appt_Time" +
                    "(Appt_Num, Slot_Num)\n" +
                    "VALUES (?,?);");

            pst.setInt(1,apptNum);
            pst.setInt(2,booking.getSlotNumber());
            pst.executeUpdate();

            pst.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }

        //insert appointment service
        try {
            pst = con.prepareStatement("INSERT INTO Appt_Svc" +
                    "(Appt_Num, Svc_Num)\n" +
                    "VALUES (?,?);");

            pst.setInt(1,apptNum);
            pst.setInt(2,booking.getServiceNumber());
            pst.executeUpdate();

            pst.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    //create member record
    private void addMemberRecord(){


        try {
            pst = con.prepareStatement("INSERT INTO Member_Record(Cust_Num, Record_Date, Record_PtsEarned, Record_Summary)\n" +
                    "VALUES(?,?,?,?);");

            pst.setInt(1,booking.getCustomerNumber());
            pst.setDate(2,booking.getDate());
            pst.setInt(3,Math.round(booking.getApptTotal()));
            pst.setString(4,"Appointment: " + booking.getService());

            pst.executeUpdate();

            pst.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
