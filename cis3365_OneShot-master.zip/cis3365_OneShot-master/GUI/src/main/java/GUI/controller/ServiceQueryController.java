package GUI.controller;

import GUI.Class.AppoinmentService;
import GUI.Class.FreqService;
import GUI.Class.PopService;
import GUI.DBconnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.text.Text;
import javafx.scene.control.TextField;
import  javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServiceQueryController implements Initializable {



    @FXML
    private Button btn_submit;

    @FXML
    private  Label label;

    @FXML
    private TextField txt_productdescription;

    @FXML
    private TextField txt_requests;

    @FXML
    private TableView<PopService> tableService;

    @FXML
    private TableColumn<?, ?> columnServiceDescription;

    @FXML
    private TableColumn<?, ?> columnRequests;

    @FXML
    private Button btn_okay;

    @FXML
    private  Button btn_clear;

    @FXML
    private Text txt_title;

    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;
    private ObservableList<FreqService> data;
    private ObservableList<PopService> data2;

    private ObservableList<AppoinmentService> service;
    @FXML
    private ComboBox<AppoinmentService> combo_service;

    private String inputNumber;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        con = GUI.DBconnection.dConnection();
        data = FXCollections.observableArrayList();
        data2 = FXCollections.observableArrayList();
        service = FXCollections.observableArrayList();
        setCellTable();
        firstfunction();
        fillServiceCombo();
    }

    private void setCellTable() {
        columnServiceDescription.setCellValueFactory(new PropertyValueFactory<>("serviceDescription"));
        columnRequests1.setCellValueFactory(new PropertyValueFactory<>("requests"));
    }

    @FXML
    private void handleSubmit1(ActionEvent event) throws IOException {

      inputNumber = txt_requests.getText();
      loadDataFromDatabase();
      //txt_title1.setText("Preferred Service \nOver " + inputNumber);
    }

    private void loadDataFromDatabase(){
       data.clear();

        try {
           pst = con.prepareStatement("SELECT \n" +
                   "Service.Svc_Desc AS 'Service Description',\n" +
                   "COUNT(S.Svc_Num) AS 'Requests'\n" +
                   " \n" +
                   "FROM Appt_Svc S\n" +
                   " JOIN Appointment A ON S.Appt_Num = A.Appt_Num\n" +
                   " JOIN Service ON S.Svc_Num = Service.Svc_Num \n" +
                   "\n" +
                   "\n" +
                   "WHERE Service.Svc_Desc = ? \n" +
                   "GROUP BY Service.Svc_Desc\n" +
                   "HAVING COUNT(S.Svc_Num) >= 1" +
                   "\n" +
                   "ORDER BY COUNT(S.Svc_Num) DESC;");
           pst.setString(1,combo_service.getSelectionModel().getSelectedItem().toString());
            //pst.setString(2,inputNumber);
            rs = pst.executeQuery();
           while (rs.next()) {
               data.add(new FreqService(rs.getString(1),rs.getString(2)));
            }
        } catch (SQLException ex){
           Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
       }
       tableService1.setItems(data);
    }

    @FXML
    private void clearTextField(ActionEvent event){
        txt_requests.clear();
        data.clear();
    }

    //To control the service combo box
    //fill the service combobox
    public void fillServiceCombo(){

        try {
            pst = con.prepareStatement("SELECT Svc_Desc FROM Service");
            rs = pst.executeQuery();

            while (rs.next()) {

                service.add(new AppoinmentService(rs.getString(1)));
            }
            pst.close();
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        combo_service.setItems(service);

    }


    /**********
     * To control popular service
     */

    @FXML
    private RadioButton above;

    @FXML
    private RadioButton below;

    @FXML
    private TextField input_value;


    @FXML
    private Button submit;


    @FXML
    private TextField txt_requests1;

    @FXML
    private TableView<FreqService> tableService1;

    @FXML
    private TableColumn<?, ?> columnService;

    @FXML
    private TableColumn<?, ?> columnRequests1;

    @FXML
    private TableColumn<?, ?> columnLastRequested;

    @FXML
    private RadioButton highScore;

    @FXML
    RadioButton lowScore;


    @FXML
    private Button btn_clear1;

    @FXML
    private Text txt_title1;

    @FXML
    private void clear(ActionEvent event) {
        data.clear();

    }

    private String threshold;


    private void firstfunction() {
        columnService.setCellValueFactory(new PropertyValueFactory<>("service"));
        columnRequests.setCellValueFactory(new PropertyValueFactory<>("requests"));
        columnLastRequested.setCellValueFactory(new PropertyValueFactory<>("lastRequested"));
    }

    @FXML
    private void handleSubmit(ActionEvent event) throws IOException {

        threshold = input_value.getText();

        if (above.isSelected()) {
            loadAbove();
        } else if (below.isSelected()) {
            loadBelow();
        } else if (highScore.isSelected()) {
            loadTop3();
        } else if (lowScore.isSelected()) {
            loadBottom3();
        }
    }

    public void loadTop3() {
        data2.clear();

        try {
            pst = con.prepareStatement("SELECT TOP 3\n" +
                    "Service.Svc_Desc AS 'Service',\n" +
                    "COUNT(Appt_Svc.Svc_Num) AS 'Requests',\n" +
                    "FORMAT(MAX(A.Appt_Date), 'MM/dd/yyyy') AS 'Last Requested'\n" +
                    "\n" +
                    "FROM Service\n" +
                    "LEFT JOIN Appt_Svc ON Appt_Svc.Svc_Num = Service.Svc_Num\n" +
                    "LEFT JOIN Appointment A ON Appt_Svc.Appt_Num = A.Appt_Num\n" +
                    "\n" +
                    "GROUP BY Service.Svc_Desc\n" +
                    "\n" +
                    "ORDER BY COUNT(Appt_Svc.Svc_Num) DESC;");
            rs = pst.executeQuery();
            while (rs.next()) {
                data2.add(new PopService(rs.getString(1), rs.getString(2), rs.getString(3)));

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        tableService.setItems(data2);
    }

    public void loadBottom3() {
        data2.clear();

        try {
            pst = con.prepareStatement("SELECT TOP 3\n" +
                    "Service.Svc_Desc AS 'Service',\n" +
                    "COUNT(Appt_Svc.Svc_Num) AS 'Requests',\n" +
                    "FORMAT(MAX(A.Appt_Date), 'MM/dd/yyyy') AS 'Last Requested'\n" +
                    "\n" +
                    "FROM Service\n" +
                    "LEFT JOIN Appt_Svc ON Appt_Svc.Svc_Num = Service.Svc_Num\n" +
                    "LEFT JOIN Appointment A ON Appt_Svc.Appt_Num = A.Appt_Num\n" +
                    "\n" +
                    "GROUP BY Service.Svc_Desc\n" +
                    "\n" +
                    "ORDER BY COUNT(Appt_Svc.Svc_Num) ASC;");
            rs = pst.executeQuery();
            while (rs.next()) {
                data2.add(new PopService(rs.getString(1), rs.getString(2), rs.getString(3)));

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        tableService.setItems(data2);

    }

    public void loadAbove() {
        data2.clear();

        try {
            pst = con.prepareStatement("SELECT \n" +
                    "Service.Svc_Desc AS 'Service Description',\n" +
                    "COUNT(S.Svc_Num) AS 'Requests',\n" +
                    "FORMAT(MAX(A.Appt_Date), 'MM/dd/yyyy') AS 'Last Requested'\n" +
                    " \n" +
                    "FROM Appt_Svc S\n" +
                    "LEFT JOIN Appointment A ON S.Appt_Num = A.Appt_Num\n" +
                    "LEFT JOIN Service ON S.Svc_Num = Service.Svc_Num \n" +
                    "\n" +
                    "\n" +
                    "GROUP BY Service.Svc_Desc\n" +
                    "HAVING COUNT(S.Svc_Num) >= ?\n" +
                    "\n" +
                    "ORDER BY COUNT(S.Svc_Num) DESC;");
            pst.setString(1, threshold);
            rs = pst.executeQuery();
            while (rs.next()) {
                data2.add(new PopService(rs.getString(1), rs.getString(2), rs.getString(3)));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        tableService.setItems(data2);
    }

    public void loadBelow() {
        data2.clear();

        try {
            pst = con.prepareStatement("SELECT \n" +
                    "Service.Svc_Desc AS 'Service Description',\n" +
                    "COUNT(S.Svc_Num) AS 'Requests',\n" +
                    "FORMAT(MAX(A.Appt_Date), 'MM/dd/yyyy') AS 'Last Requested'\n" +
                    " \n" +
                    "FROM Appt_Svc S\n" +
                    "LEFT JOIN Appointment A ON S.Appt_Num = A.Appt_Num\n" +
                    "LEFT JOIN Service ON S.Svc_Num = Service.Svc_Num \n" +
                    "\n" +
                    "\n" +
                    "GROUP BY Service.Svc_Desc\n" +
                    "HAVING COUNT(S.Svc_Num) <= ?\n" +
                    "\n" +
                    "ORDER BY COUNT(S.Svc_Num) DESC;");
            pst.setString(1, threshold);
            rs = pst.executeQuery();
            while (rs.next()) {
                data2.add(new PopService(rs.getString(1), rs.getString(2), rs.getString(3)));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        tableService.setItems(data2);
    }

    /**********
     * Menu controls
     */

    @FXML
    //opens up the Membership Reports Screen
    private void launchMembershipReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/membershipQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
        //switchView("membershipQueries.fxml");
    }

    @FXML
    //opens up the customer Dashboard Screen
    public void launchCustomerReport(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/CustomerReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //opens up the Employee Dashboard Screen
    public void launchEmployeeDashboard(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employeeReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointment Reports dashboard
    private void launchAppointmentReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appointmentQuery.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointments screen
    private void launchAppointments(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Employees screen
    private void launchEmployees(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee1.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory Reports screen
    private void launchInventoryReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventoryQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory screen
    public void launchInventory(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventory.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Customer screen
    private void launchCustomers(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/customer.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the services screen
    private void launchServices(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/service.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    private void launchScheduleReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/ScheduleQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }


}
