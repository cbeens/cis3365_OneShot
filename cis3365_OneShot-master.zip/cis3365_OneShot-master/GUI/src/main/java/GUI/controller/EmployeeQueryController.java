package GUI.controller;

import GUI.Class.FreqEmployees;
import GUI.Class.license;
import GUI.Class.popularEmployee;
import GUI.DBconnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EmployeeQueryController implements Initializable {
    @FXML
    public TableView<popularEmployee> PopEmpTableview;
    @FXML
    public TableView<popularEmployee> PopEmpTableview2;
    @FXML
    public TableView<FreqEmployees> FreEmpTableview;
    @FXML
    public TableView<FreqEmployees> FreEmpTableview2;
    @FXML
    public TableView<license> licenseTableView;
    @FXML
    private TableColumn<?,?> col1;
    @FXML
    private TableColumn<?,?> col2;
    @FXML
    private TableColumn<?,?> col3;
    @FXML
    private TableColumn<?,?> col4;
    @FXML
    private TableColumn<?,?> col5;
    @FXML
    private TableColumn<?,?> col6;
    @FXML
    private TableColumn<?,?> col7;
    @FXML
    private TableColumn<?,?> col8;
    @FXML
    private TableColumn<?,?> col9;
    @FXML
    private TableColumn<?,?> col10;
    @FXML
    private TableColumn<?,?> col11;
    @FXML
    private TableColumn<?,?> col12;
    @FXML
    private TableColumn<?,?> col13;
    @FXML
    private TableColumn<?,?> col14;
    @FXML
    private TableColumn<?,?> col15;
    @FXML
    private TableColumn<?,?> col16;
    @FXML
    private TableColumn<?,?> col17;
    @FXML
    private TableColumn<?,?> col18;
    @FXML
    private TableColumn<?,?> col19;
    @FXML
    private TableColumn<?,?> col20;
    @FXML
    private TableColumn<?,?> col21;
    @FXML
    private TableColumn<?,?> col22;

    @FXML
    private DatePicker datePicker;




    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs= null;
    private ObservableList<popularEmployee> least;
    private ObservableList<popularEmployee> most;
    private ObservableList<FreqEmployees> less;
    private ObservableList<FreqEmployees> more;
    private ObservableList<license> licenses;

    public void initialize(URL url, ResourceBundle rb) {
        setTables();
        con = GUI.DBconnection.dConnection();
        least = FXCollections.observableArrayList();
        most = FXCollections.observableArrayList();
        less = FXCollections.observableArrayList();
        more = FXCollections.observableArrayList();
        licenses = FXCollections.observableArrayList();
        //loadLeastPopular();
        //loadMostPopular();
        //loadFrequent();
        //loadLessFrequent();
        loadExpiredLicenses();

    }

    //this function is to set all the tables
    public void setTables() {

        //Least Popular Employee
        col1.setCellValueFactory(new PropertyValueFactory<>("month"));
        col2.setCellValueFactory(new PropertyValueFactory<>("employee"));
        col3.setCellValueFactory(new PropertyValueFactory<>("appointment"));
        col4.setCellValueFactory(new PropertyValueFactory<>("guest"));
        col5.setCellValueFactory(new PropertyValueFactory<>("location"));

        //Most Popular Employee
        col6.setCellValueFactory(new PropertyValueFactory<>("month"));
        col7.setCellValueFactory(new PropertyValueFactory<>("employee"));
        col8.setCellValueFactory(new PropertyValueFactory<>("appointment"));
        col9.setCellValueFactory(new PropertyValueFactory<>("guest"));
        col10.setCellValueFactory(new PropertyValueFactory<>("location"));

        //Less Frequent Employees
        col11.setCellValueFactory(new PropertyValueFactory<>("week"));
        col12.setCellValueFactory(new PropertyValueFactory<>("Employee"));
        col13.setCellValueFactory(new PropertyValueFactory<>("days_work"));
        col14.setCellValueFactory(new PropertyValueFactory<>("shift_work"));
        col15.setCellValueFactory(new PropertyValueFactory<>("hours_work"));

        //Frequent employees
        col16.setCellValueFactory(new PropertyValueFactory<>("week"));
        col17.setCellValueFactory(new PropertyValueFactory<>("Employee"));
        col18.setCellValueFactory(new PropertyValueFactory<>("days_work"));
        col19.setCellValueFactory(new PropertyValueFactory<>("shift_work"));
        col20.setCellValueFactory(new PropertyValueFactory<>("hours_work"));

        //expiring licenses
        col21.setCellValueFactory(new PropertyValueFactory<>("employee"));
        col22.setCellValueFactory(new PropertyValueFactory<>("expire"));
    }

    /********
     *The following functions are to load the tables
     ********/

    //this holds input month for tables.
    private Date sqlDate;

    @FXML//this allows the date to be used for the tables
    private void submitDate(ActionEvent event) {

        sqlDate = java.sql.Date.valueOf(datePicker.getValue());
        loadLeastPopular();
        loadMostPopular();
        loadFrequent();
        loadLessFrequent();
    }

    @FXML//this clears the tables
    private void clear(ActionEvent event) {
        least.clear();
        most.clear();
        less.clear();
        more.clear();
    }

    //this loads query Andy_LeastPopularEmployee
    public void loadLeastPopular(){
        try {
            pst = con.prepareStatement("SELECT TOP 1\n" +
                    "MONTH(W.Week_Start) AS 'Month Number',\n" +
                    "CONCAT(E.Emp_Firstname, ' ', E.Emp_Lastname) AS 'Bottom Employee',\n" +
                    "COUNT(A.Appt_Num) AS 'Number of Appointments',\n" +
                    "COUNT(A.Cust_Num) AS 'Number of Guests',\n" +
                    "L.Loc_Street AS Location\n" +
                    "\n" +
                    "\n" +
                    "FROM Appointment A\n" +
                    "\n" +
                    "INNER JOIN Employee E ON A.Emp_Num = E.Emp_Num\n" +
                    "INNER JOIN Location L ON L.Loc_Num = A.Loc_Num\n" +
                    "INNER JOIN Week_Day D ON A.Appt_Date = D.Day_Date\n" +
                    "JOIN Work_Week W ON W.Week_Num = D.Week_Num\n" +
                    "\n" +
                    "WHERE MONTH(W.Week_Start) = MONTH(?)" +
                    "AND YEAR(W.Week_End) = YEAR(?)" +
                    "\n" +
                    "GROUP BY L.Loc_Street, E.Emp_Firstname, E.Emp_Lastname, W.Week_Start, W.Week_End\n" +
                    "\n" +
                    "ORDER BY COUNT(A.Appt_Num) ASC;");
            pst.setDate(1,sqlDate);
            pst.setDate(2,sqlDate);
            rs = pst.executeQuery();
            while(rs.next()){
                least.add(new popularEmployee(""+rs.getString(1),rs.getString(2),
                        ""+rs.getString(3),""+rs.getString(4),rs.getString(5)));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        PopEmpTableview.setItems(least);

    }

    //this loads the query Andy_PopularEmployee
    public void loadMostPopular(){

        try {
            pst = con.prepareStatement("SELECT TOP 1\n" +
                    "MONTH(W.Week_Start) AS 'Month Number',\n" +
                    "CONCAT(E.Emp_Firstname, ' ', E.Emp_Lastname) AS 'Top Employee',\n" +
                    "COUNT(A.Appt_Num) AS 'Number of Appointments',\n" +
                    "COUNT(A.Cust_Num) AS 'Number of Guests',\n" +
                    "L.Loc_Street AS Location\n" +
                    "\n" +
                    "\n" +
                    "FROM Appointment A\n" +
                    "\n" +
                    "INNER JOIN Employee E ON A.Emp_Num = E.Emp_Num\n" +
                    "INNER JOIN Location L ON L.Loc_Num = A.Loc_Num\n" +
                    "INNER JOIN Week_Day D ON A.Appt_Date = D.Day_Date\n" +
                    "JOIN Work_Week W ON W.Week_Num = D.Week_Num\n" +
                    "\n" +
                    "WHERE MONTH(W.Week_Start) = MONTH(?)" +
                    "AND YEAR(W.Week_End) = YEAR(?)" +
                    "\n" +
                    "GROUP BY L.Loc_Street, E.Emp_Firstname, E.Emp_Lastname, W.Week_Start, W.Week_End\n" +
                    "\n" +
                    "ORDER BY COUNT(A.Appt_Num) DESC;");
            pst.setDate(1,sqlDate);
            pst.setDate(2,sqlDate);
            rs = pst.executeQuery();
            while(rs.next()){
                most.add(new popularEmployee(""+rs.getString(1),rs.getString(2),
                        ""+rs.getString(3),""+rs.getString(4),rs.getString(5)));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        PopEmpTableview2.setItems(most);
    }

    //this loads the query_Luis_LessEmployees
    public void loadLessFrequent() {
        try {
            pst = con.prepareStatement("SELECT\n" +
                    "FORMAT(Work_Week.Week_End, 'MM/dd/yyyy') AS 'Week Ending',\n" +
                    "CONCAT(Employee.Emp_Firstname, ' ', Employee.Emp_Lastname) AS 'Employee', \n" +
                    " \n" +
                    "COUNT(Emp_Schedule.Day_Date) AS 'Days Worked', \n" +
                    "COUNT(Emp_Schedule.Emp_Hours) AS 'Shifts Worked',  \n" +
                    "SUM(Emp_Schedule.Emp_Hours) AS 'Hours Worked'\n" +
                    "\n" +
                    "FROM Employee\n" +
                    "FULL OUTER JOIN Emp_Schedule ON Employee.Emp_Num = Emp_Schedule.Emp_Num\n" +
                    "LEFT OUTER JOIN Week_Day ON Emp_Schedule.Day_Date = Week_Day.Day_Date\n" +
                    "JOIN Work_Week ON Week_Day.Week_Num = Work_Week.Week_Num\n" +
                    "\n" +
                    "WHERE MONTH(Work_Week.Week_Start) = MONTH(?)" +
                    "AND YEAR(Work_Week.Week_Start) = YEAR(?)" +
                    "\n" +
                    "GROUP BY Week_End, Employee.Emp_Firstname, Employee.Emp_Lastname\n" +
                    "\n" +
                    "ORDER BY SUM(Emp_Schedule.Emp_Hours) ASC;");
            pst.setDate(1,sqlDate);
            pst.setDate(2,sqlDate);
            rs = pst.executeQuery();
            while(rs.next()){
                less.add(new FreqEmployees(""+rs.getString(1),""+rs.getString(2),
                        ""+rs.getString(3),""+rs.getString(4),""+rs.getString(5)));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        FreEmpTableview2.setItems(less);
    }

    //this loads the query Luis_FreqEmployees
    public void loadFrequent() {
        try {
            pst = con.prepareStatement("SELECT\n" +
                    "FORMAT(Work_Week.Week_End, 'MM/dd/yyyy') AS 'Week',\n" +
                    "CONCAT(Employee.Emp_Firstname, ' ', Employee.Emp_Lastname) AS 'Employee', \n" +
                    "COUNT(Emp_Schedule.Day_Date) AS 'Days Worked', \n" +
                    "COUNT(Emp_Schedule.Emp_Hours) AS 'Shifts Worked',  \n" +
                    "SUM(Emp_Schedule.Emp_Hours) AS 'Hours Worked'\n" +
                    "\n" +
                    "FROM Employee\n" +
                    "FULL OUTER JOIN Emp_Schedule ON Employee.Emp_Num = Emp_Schedule.Emp_Num\n" +
                    "LEFT OUTER JOIN Week_Day ON Emp_Schedule.Day_Date = Week_Day.Day_Date\n" +
                    "JOIN Work_Week ON Week_Day.Week_Num = Work_Week.Week_Num\n" +
                    "\n" +
                    "\n" +
                    "WHERE MONTH(Week_End) = MONTH(?)" +
                    "AND YEAR(Week_End) = YEAR(?)" +
                    "\n" +
                    "GROUP BY Week_End, Employee.Emp_Firstname, Employee.Emp_Lastname\n" +
                    "\n" +
                    "ORDER BY SUM(Emp_Schedule.Emp_Hours) DESC;");
            pst.setDate(1,sqlDate);
            pst.setDate(2,sqlDate);
            rs = pst.executeQuery();
            while(rs.next()){
                more.add(new FreqEmployees(""+rs.getString(1),""+rs.getString(2),
                        ""+rs.getString(3),""+rs.getString(4),""+rs.getString(5)));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        FreEmpTableview.setItems(more);
    }

    //this loads the query Jesse_LicensesExpire
    public void loadExpiredLicenses() {
        try {
            pst = con.prepareStatement("\n" +
                    "SELECT \n" +
                    "CONCAT(Employee.Emp_Firstname, ' ', Employee.Emp_Lastname) AS Employee,\n" +
                    "FORMAT(Emp_License.Lic_Expire, 'MM/dd/yyyy') AS 'License Expires'\n" +
                    "\n" +
                    "FROM Employee\n" +
                    "LEFT JOIN Emp_License ON Emp_License.Emp_Num = Employee.Emp_Num\n" +
                    "LEFT JOIN License ON License.License_Num = Emp_License.Lic_Num\n" +
                    "\n" +
                    "WHERE Emp_License.Lic_Expire <= DATEADD(dd, 30, GETDATE());");
            rs = pst.executeQuery();
            while(rs.next()){
                licenses.add(new license(rs.getString(1),rs.getString(2)));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        licenseTableView.setItems(licenses);
    }

    /***********
     * The following functions change the screen based on menu options
     */

    @FXML
    //opens up the Membership Reports Screen
    private void launchMembershipReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/membershipQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
        //switchView("membershipQueries.fxml");
    }

    @FXML
    //opens up the customer Dashboard Screen
    public void launchCustomerReport(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/CustomerReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointment Reports dashboard
    private void launchAppointmentReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appointmentQuery.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointments screen
    private void launchAppointments(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Employees screen
    private void launchEmployees(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee1.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory Reports screen
    private void launchInventoryReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventoryQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory screen
    public void launchInventory(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventory.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Customer screen
    private void launchCustomers(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/customer.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the services screen
    private void launchServices(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/service.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the service reports screen
    private void launchServiceReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/serviceQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }
    @FXML
    private void launchScheduleReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/ScheduleQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

}
