package GUI.controller;

import GUI.Class.employee;
import GUI.DBconnection;
import GUI.validation.FieldValidation;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;


public class EmployeeController implements Initializable {

    @FXML
    private StackPane mainContainer;
    @FXML
    public TableView<employee> tableview;
    @FXML
    private TableColumn<?, ?> col1;
    @FXML
    private TableColumn<?, ?> col2;
    @FXML
    private TableColumn<?, ?> col3;
    @FXML
    private TableColumn<?, ?> col4;
    @FXML
    private TableColumn<?, ?> col5;
    @FXML
    private TableColumn<?, ?> col6;
    @FXML
    private TableColumn<?, ?> col7;

    @FXML
    private TextField fName;

    @FXML
    private TextField lName;

    @FXML
    private TextField PhoneNumber;

    @FXML
    private TextField streetText;

    @FXML
    private TextField zip;

    @FXML
    private TextField SSN;

    @FXML
    private RadioButton r_manager;

    @FXML
    private ToggleGroup role;

    @FXML
    private RadioButton r_servicer;

    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;
    private ObservableList<employee> data;
    @FXML
    private Label error_fname;
    @FXML
    private Label error_lname;
    @FXML
    private Label error_phone;
    @FXML
    private Label error_address;
    @FXML
    private Label error_SSN;


    public void initialize(URL url, ResourceBundle rb) {
        firstfunction();
        con = GUI.DBconnection.dConnection();
        data = FXCollections.observableArrayList();
        loadData();
        //setCellValueWhileClieckTable();
    }

    public void firstfunction() {
        //set up tableview
        col1.setCellValueFactory(new PropertyValueFactory<>("id"));
        col2.setCellValueFactory(new PropertyValueFactory<>("name"));
        col3.setCellValueFactory(new PropertyValueFactory<>("Phone"));
        col4.setCellValueFactory(new PropertyValueFactory<>("address"));
        col5.setCellValueFactory(new PropertyValueFactory<>("role"));
        col6.setCellValueFactory(new PropertyValueFactory<>("SSN"));
        col7.setCellValueFactory(new PropertyValueFactory<>("date"));
        //   tableview.setItems(originalPatient());
        // updata tableview
        tableview.setEditable(true);

        tableview.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    public void loadData() {
        data.clear();
        try {
            pst = con.prepareStatement("    SELECT\n" +
                    "           Emp_Num, " +
                    "CONCAT(Emp_Firstname, ' ', Emp_Lastname) Name,\n" +
                    "           Emp_Phone AS Phone,\n" +
                    "           CONCAT(Emp_Street, ', ', Zip.Zip_City) AS Address,\n" +
                    "           Emp_Role.Role_Description AS Role,\n" +
                    "\t\t   Emp_SSN,\n" +
                    "           FORMAT(Emp_HireDate, 'MM/dd/yyyy') AS 'Hire Date'\n" +
                    "\n" +
                    "    FROM dbo.Employee\n" +
                    "      INNER JOIN Zip ON Employee.Zip_Num = Zip.Zip_Num\n" +
                    "\t  INNER JOIN Emp_Role ON Employee.Role_Num = Emp_Role.Role_Num\n" +
                    "\n" +
                    "    ORDER BY Emp_Num ASC;");
            rs = pst.executeQuery();
            while (rs.next()) {
                data.add(new employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
                        rs.getString(5), rs.getString(6), rs.getString(7)));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        tableview.setItems(data);

    }


    public void addEmployee() {
        //boolean filedoneEmpty = FieldValidation.isFieldNotEmpty(fName, error_fname, "Required");
        //boolean filedtwoEmpty = FieldValidation.isFieldNotEmpty(lName, error_lname, "Required");
        //boolean filedthreeEmpty = FieldValidation.isFieldNotEmpty(PhoneNumber, error_phone, "Required");
        //boolean filedfourEmpty = FieldValidation.isFieldNotEmpty(streetText, error_address, "Required");
        //boolean filedfiveEmpty = FieldValidation.isFieldNotEmpty(SSN, error_SSN, "Required");


        int empZip = 0;
        int empRole;

        //if (filedfiveEmpty && filedfourEmpty && filedthreeEmpty && filedtwoEmpty && filedoneEmpty) {

            try {
                pst = con.prepareStatement("SELECT Zip.Zip_Num \n" +
                        "FROM Zip \n" +
                        "WHERE Zip.Zip_Code = ?;");
                pst.setString(1,zip.getText());
                rs = pst.executeQuery();

                if(rs.next())
                    empZip = rs.getInt(1);

            } catch (SQLException ex) {
                Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
            }

            if (r_manager.isSelected())
                    empRole = 1;

            else
                empRole = 2;


            String sql = "Insert into dbo.Employee(Emp_Lastname,Emp_Firstname,Emp_Phone,Emp_SSN, Emp_Street, Emp_HireDate, Zip_Num, Role_Num) Values(?,?,?,?,?,?,?,?)";


            String fname = fName.getText();
            String lname = lName.getText();
            String phone = PhoneNumber.getText();
            String ssn = SSN.getText();
            String street = streetText.getText();
            Date hireDate = Date.valueOf(LocalDate.now());


            try {
                pst = con.prepareStatement(sql);
                pst.setString(1, lname);
                pst.setString(2, fname);
                pst.setString(3, phone);
                pst.setString(4, ssn);
                pst.setString(5, street);
                pst.setDate(6, hireDate);
                pst.setInt(7,empZip);
                pst.setInt(8,empRole);

                int i = pst.executeUpdate();
                if (i == 1) {
                    System.out.print("Successful");

                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        loadData();

        //}
    }

    /*
    private void clearfield() {
        fName.clear();
        lName.clear();
        zip.clear();
        SSN.clear();
        PhoneNumber.clear();
        street.clear();
        data.clear();
    }
    */

    public void deleteEmployee() {

        ObservableList<employee> selectRow;
        int toDelete = 0;

        //select items
        selectRow = tableview.getSelectionModel().getSelectedItems();



        for (employee employee : selectRow) {
            tableview.getItems().remove(employee);
            toDelete = employee.getId();
        }


        try {
            pst = con.prepareStatement("DELETE FROM Employee \n" +
                    "WHERE Emp_Num = ?;");
            pst.setInt(1,toDelete);

            int i = pst.executeUpdate();
            if (i == 1) {
                System.out.print("Successful");
                loadData();
            }
        } catch (SQLException e) {
            e.printStackTrace(); }


    }


    /*
    private void setCellValueWhileClieckTable() {
        tableview.setOnMouseClicked(e -> {
            employee em = tableview.getItems().get(tableview.getSelectionModel().getSelectedIndex());
            fName.setText(em.getFirstName());
            lName.setText(em.getLastName());
            PhoneNumber.setText(em.getPhone());
            dates.setText(em.getDate());
            SSN.setText(em.getSSN());
            address.setText(em.getAddress());
            email.setText(em.getRole());
        });


    }

    public void updateData() {
        String sql = "Update dbo.Employee set Emp_Lastname = ?,Emp_Firstname = ?,Emp_HireDate = ?,Emp_Phone = ?,Emp_Street= ? where Emp_SSN = ?";
        try {
            pst = con.prepareStatement(sql);
            String fname = fName.getText();
            String lname = lName.getText();
            String phonen = PhoneNumber.getText();
            String ssn = SSN.getText();
            String street = address.getText();
            String date = dates.getText();

            pst.setString(1, lname);
            pst.setString(2, fname);
            pst.setString(3, date);
            pst.setString(4, phonen);
            pst.setString(5, street);
            pst.setString(6, ssn);

            int i = pst.executeUpdate();
            if (i == 1) {
                loaddata();

            }
        } catch (SQLException e) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, e);
        }


    }
    */


    /*****
     * Switchviews....
     * @throws Exception
     */


/*
    public void appoinment() throws Exception {
        switchView("appoinment.fxml");
    }

    public void employee() throws Exception {
        switchView("employee.fxml");
    }
    public void employee1() throws Exception {
        switchView("employee1.fxml");
    }
    public void inventory() throws Exception {
        switchView("invemtory.fxml");
    }
    public void inventory1() throws Exception {
        switchView("inventory1.fxml");
    }
    public void membership() throws Exception {
        switchView("membership.fxml");
    }
    public void other() throws Exception {
        switchView("other.fxml");
    }
    public void service() throws Exception {
        switchView("service.fxml");
    }
    public void service1() throws Exception {
        switchView("service1.fxml");
    }

    private void switchView(String fileName) throws Exception {

        mainContainer.getChildren().clear();
        AnchorPane anchorPane = new FXMLLoader(getClass().getResource("/fxml/" + fileName)).load();
        mainContainer.getChildren().add(anchorPane);
    }
*/



    /*******
     * menu controls
     */

    @FXML
    //opens up the Membership Reports Screen
    private void launchMembershipReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/membershipQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
        //switchView("membershipQueries.fxml");
    }

    @FXML
    //opens up the Employee Dashboard Screen
    public void launchEmployeeDashboard(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employeeReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointment Reports dashboard
    private void launchAppointmentReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appointmentQuery.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointments screen
    private void launchAppointments(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory Reports screen
    private void launchInventoryReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventoryQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory screen
    private void launchInventory(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventory.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Customer screen
    private void launchCustomers(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/customer.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the services screen
    private void launchServices(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/service.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the service reports screen
    private void launchServiceReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/serviceQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }


}






