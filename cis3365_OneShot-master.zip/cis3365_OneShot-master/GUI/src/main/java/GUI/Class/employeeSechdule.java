package GUI.Class;

public class employeeSechdule {
    private int employeenumber;
    private int locationnumber;
    private String date;
    private int shiftnumber;


    public int getEmployeenumber() {
        return employeenumber;
    }

    public void setEmployeenumber(int employeenumber) {
        this.employeenumber = employeenumber;
    }

    public int getLocationnumber() {
        return locationnumber;
    }

    public void setLocationnumber(int locationnumber) {
        this.locationnumber = locationnumber;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getShiftnumber() {
        return shiftnumber;
    }

    public void setShiftnumber(int shiftnumber) {
        this.shiftnumber = shiftnumber;
    }
}
