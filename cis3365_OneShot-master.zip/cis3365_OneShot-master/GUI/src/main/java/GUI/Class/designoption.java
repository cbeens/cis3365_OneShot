package GUI.Class;

public class designoption {
    private int designnumber;
    private String desc;


    public int getDesignnumber() {
        return designnumber;
    }

    public void setDesignnumber(int designnumber) {
        this.designnumber = designnumber;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
