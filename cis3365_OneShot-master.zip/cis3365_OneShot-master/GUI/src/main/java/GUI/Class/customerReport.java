package GUI.Class;

public class customerReport {
    private
    String name, visit, ser, location, total_service, date, spend;

    public customerReport(String n, String v, String s, String l){
        this.name=n;
        this.visit=v;
        this.ser=s;
        this.location=l;
    }

    public customerReport(String n, String v, String ts, String l , String date){
        this.name=n;
        this.visit=v;
        this.total_service=ts;
        this.location=l;
        this.date = date;
    }
    public customerReport(String n, String v, String s, String l, String d, String h){
        this.name=n;
        this.visit=v;
        this.spend=s;
        this.location=l;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVisit() {
        return visit;
    }

    public void setVisit(String visit) {
        this.visit = visit;
    }

    public String getServicer() {
        return ser;
    }

    public void setServicer(String servicer) {
        this.ser = servicer;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getTotal_service() {
        return total_service;
    }

    public void setTotal_service(String total_service) {
        this.total_service = total_service;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSpend() {
        return spend;
    }

    public void setSpend(String spend) {
        this.spend = spend;
    }
}
