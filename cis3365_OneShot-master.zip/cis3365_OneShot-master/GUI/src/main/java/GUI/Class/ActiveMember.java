package GUI.Class;

public class ActiveMember {


        private String memberName;
        private String memberType;
        private String memberSince;
        private String memberExpire;


        //getter and setter for member since
        public String getMemberSince() {
            return memberSince;
        }
        public void setMemberSince(String since) {
            this.memberSince = since;
        }

        //getter and setter for member name
        public String getMemberName() {
            return memberName;
        }
        public void setMemberName(String name) {
            this.memberName = name;
        }

        //getter and setter for member type
        public String getMemberType() {
            return memberType;
        }
        public void setMemberType(String type) {
            this.memberType = type;
        }

        //getter and setter for member since
        public String getMemberExpire() {
        return memberExpire;
    }
        public void setMemberExpire(String expire) {
        this.memberExpire = expire;
    }



        @Override
        public String toString() {
            return "Member{" +
                    ", Name='" + memberName + '\'' +
                    ", Type ='" + memberType + '\'' +
                    ", Since='" + memberSince + '\'' +
                    ", Expire='" + memberExpire + '}';
        }


        //constructor...
        public ActiveMember(String name, String type, String since, String expire) {
            this.memberName = name;
            this.memberType = type;
            this.memberSince = since;
            this.memberExpire = expire;
        }


}
