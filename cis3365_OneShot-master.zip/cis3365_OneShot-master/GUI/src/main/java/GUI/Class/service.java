package GUI.Class;

import java.math.BigDecimal;

public class service {
    private int number;
    private String Des;
    private String price;

    public service() {
    }


    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getDes() {
        return Des;
    }

    public void setDes(String des) {
        Des = des;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public service(int n, String d, String p) {
        this.number = n;
        this.Des = d;
        this.price = p;

    }
}
