package GUI.Class;

public class AppoinmentService {
    private int AppoinmentNumber;
    private int ServiceNumber;
    private String service;

    //this is for appointment booking.
    public AppoinmentService(String service){
        this.service = service;
    }

    public String toString(){
        return service;
    }

    public int getAppoinmentNumber() {
        return AppoinmentNumber;
    }

    public void setAppoinmentNumber(int appoinmentNumber) {
        AppoinmentNumber = appoinmentNumber;
    }

    public int getServiceNumber() {
        return ServiceNumber;
    }

    public void setServiceNumber(int serviceNumber) {
        ServiceNumber = serviceNumber;
    }
}
