package GUI.Class;

public class zipcode {

    private String stateabbr;
    private String code;

    public String getStateabbr() {
        return stateabbr;
    }

    public void setStateabbr(String stateabbr) {
        this.stateabbr = stateabbr;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
