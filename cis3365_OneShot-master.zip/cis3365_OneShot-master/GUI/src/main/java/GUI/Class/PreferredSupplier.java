package GUI.Class;

public class PreferredSupplier {
    private String supplier;
    private String product;
    private String orders;
    private String totalQTYOrdered;
    private String totalSpent;

    public PreferredSupplier(String supplier, String product, String orders, String qty, String spent) {
        this.supplier = supplier;
        this.product = product;
        this.orders = orders;
        this.totalQTYOrdered = qty;
        this.totalSpent = spent;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier){
        this.supplier = supplier;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product){
        this.product = product;
    }

    public String getOrders() {
        return orders;
    }

    public void setOrders(String orders){
        this.orders = orders;
    }

    public String getTotalQTYOrdered() {
        return totalQTYOrdered;
    }

    public void setTotalQTYOrdered(String qty){
        this.totalQTYOrdered = qty;
    }

    public String getTotalSpent() {
        return totalSpent;
    }

    public void setTotalSpent(String spent){
        this.totalSpent = spent;
    }

    @Override
    public String toString(){
        return "Supplier{" +
                ", Supplier ='" + supplier + '\'' +
                ", Product ='" + product + '\'' +
                ", Orders ='" + orders + '\'' +
                ", Total QTY Ordered ='" + totalQTYOrdered + '\'' +
                ", Total Spent ='" + totalSpent + '\'' +
                '}';
    }





}
