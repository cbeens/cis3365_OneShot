package GUI.Class;

import javafx.beans.property.SimpleStringProperty;

import java.time.LocalDate;

public class customer {

    private int num;
    private String lastName;
    private String firstName;
    private String phone;
    private String email;



    //get and set customer number
    public int getNum() {
        return num;
    }
    public void setNum(int id) {
        this.num = id;
    }

    //get and set customer phone
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        phone = phone;
    }

    //get and set email
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    //get and set last name..
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastname) {
        this.lastName = lastname;
    }

    //..first name
    public String getFirstName() {
        return firstName;
    }
    public void setFirstname(String firstname) {
        this.firstName = firstname;
    }



    @Override
    public String toString() {
        return "Customer{" +
                "#=" + num +
                ", Firstname='" + firstName + '\'' +
                ", Lastname='" + lastName + '\'' +
                ", Phone='" + phone + '\'' +
                ", Email='" + email + '\'' +

                '}';
    }



    //constructor
    public customer(int id, String first, String last, String phoneNumber, String mail) {
        this.num = id;
        this.firstName = first;
        this.lastName = last;
        this.phone = phoneNumber;
        this.email = mail;
    }


}
