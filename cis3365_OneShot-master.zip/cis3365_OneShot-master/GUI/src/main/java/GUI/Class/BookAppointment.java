package GUI.Class;

import java.sql.Date;
import java.time.LocalDate;

public class BookAppointment {

    //variables to hold appointment info
    private String customerFirst;
    private String customerLast;
    private boolean isMember = false;
    private String timeSlot;
    private String Location;
    private String employee;
    private int employeeNumber;
    private int customerNumber;
    private String service;
    private int serviceNumber;
    private Date date;
    private int locationNumber;
    private int slotNumber;
    private int apptNumber;
    private float apptTotal;

    public float getApptTotal() {
        return apptTotal;
    }

    public void setApptTotal(float apptTotal) {
        this.apptTotal = apptTotal;
    }

    public void setApptNumber(int apptNumber) {
        this.apptNumber = apptNumber;
    }

    public int getApptNumber() {
        return apptNumber;
    }

    public int getSlotNumber() {
        return slotNumber;
    }

    public void setSlotNumber(int slotNumber) {
        this.slotNumber = slotNumber;
    }

    public String getCustomerFirst() {
        return customerFirst;
    }
    public void setCustomerFirst(String customerFirst) {
        this.customerFirst = customerFirst;
    }

    public String getCustomerLast() {
        return customerLast;
    }
    public void setCustomerLast(String customerLast) {
        this.customerLast = customerLast;
    }

    public int getCustomerNumber() {
        return customerNumber;
    }
    public void setCustomerNumber(int customerNumber) {
        this.customerNumber = customerNumber;
    }

    public boolean getIsMember(){return isMember;}
    public void setIsMember(boolean member)
    {
        this.isMember = member;
    }

    public String getTimeSlot() {
        return timeSlot;
    }
    public void setTimeSlot(String timeSlot) {
        this.timeSlot = timeSlot;
    }

    public String getEmployee() {
        return employee;
    }
    public void setEmployee(String employee) {
        this.employee = employee;
    }

    public String getService() {
        return service;
    }
    public void setService(String service) {
        this.service = service;
    }

    public int getServiceNumber() {
        return serviceNumber;
    }
    public void setServiceNumber(int serviceNumber) {
        this.serviceNumber = serviceNumber;
    }

    public String getLocation() {
        return Location;
    }
    public void setLocation(String location) {
        Location = location;
    }

    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }

    public int getEmployeeNumber() {
        return employeeNumber;
    }

    public void setEmployeeNumber(int employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    public int getLocationNumber() {
        return locationNumber;
    }
    public void setLocationNumber(int locationNumber) {
        this.locationNumber = locationNumber;
    }
}
