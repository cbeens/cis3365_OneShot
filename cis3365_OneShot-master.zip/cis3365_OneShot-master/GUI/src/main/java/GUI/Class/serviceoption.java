package GUI.Class;

public class serviceoption {
    private int servicenumber;
    private int designnumber;
    private int colornumber;
    private int typenumber;


    public int getServicenumber() {
        return servicenumber;
    }

    public void setServicenumber(int servicenumber) {
        this.servicenumber = servicenumber;
    }

    public int getDesignnumber() {
        return designnumber;
    }

    public void setDesignnumber(int designnumber) {
        this.designnumber = designnumber;
    }

    public int getColornumber() {
        return colornumber;
    }

    public void setColornumber(int colornumber) {
        this.colornumber = colornumber;
    }

    public int getTypenumber() {
        return typenumber;
    }

    public void setTypenumber(int typenumber) {
        this.typenumber = typenumber;
    }
}
