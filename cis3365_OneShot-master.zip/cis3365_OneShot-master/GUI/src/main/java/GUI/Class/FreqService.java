package GUI.Class;

public class FreqService {
    private String serviceDescription;
    private String requests;

    public FreqService(String description, String requests) {
        this.serviceDescription = description;
        this.requests = requests;
    }

    public String getServiceDescription(){
        return serviceDescription;
    }

    public void setServiceDescription(String description) {
        this.serviceDescription = description;
    }

    public String getRequests(){
        return requests = requests;
    }

    public void setRequests(String requests){
        this.requests = requests;
    }

    @Override
    public String toString() {
        return "Service{" +
                ", Service Description ='" + serviceDescription + '\'' +
                ", Requests ='" + requests + '\'' +
                '}';
    }

}
